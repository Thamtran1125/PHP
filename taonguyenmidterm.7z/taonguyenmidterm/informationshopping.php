<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>MID TERM TEST</title>
	<link rel="stylesheet" href="informationshopping.css">
	<link rel="stylesheet" type="text/css" href="function.php">
</head>
<body>


	<?php

	$ID_Product = $_POST["product_id"];
	$Product_Name = $_POST["nameproduct"];
	$Quantity = $_POST["quantity"];
	$Price = $_POST["price"];
	$Amount = $_POST["amount"];

	include 'functioninfor.php';

	$Amount = caculate1($Quantity, $Price);

	$Disscount = caculate2($Quantity,$Price);

	$Total = calculate3($Quantity,$Price);

	?>





	<?php 
	$STT = 1;
	$information_shopping = array("STT"=>$STT, "product_id"=> $ID_Product, "nameproduct"=> $Product_Name, "quantity"=> $Quantity, "price"=> $Price,"disscount" => $Disscount , "amount"=> $Amount,  "total"=>$Total);
	// nhap gia tri vao cho mang
	$information_shopping["STT"] = $STT++;
	$information_shopping["product_id"] = $ID_Product;
	$information_shopping["nameproduct"] = $Product_Name;
	$information_shopping["quantity"] = $Quantity;
	$information_shopping["price"] = $Price;
	$information_shopping["disscount"] =$Disscount;
	$information_shopping["amount"] = $Amount;
	$information_shopping["total"] = $Total;

	?>

	<form action="informationshopping.php" method="post" accept-charset="utf-8">
		<table width="500" height="400" border="2" align="center" bordercolor="#660099" >
			<tr>
				<th colspan="2" rowspan="" headers="" scope="row">INFORMATION SHOPPING
				</th>
			</tr>

			<tr>
				<th class="center" colspan="" rowspan="" headers="" scope="row">ID_Product</th>
				<td><label>
					<input type="text" name="product_id" id="prd" value="<?php echo $ID_Product; ?>">
				</label></td>
			</tr>

			<tr>
				<th colspan="" rowspan="" headers="" scope="row" class="center">Product_Name</th>
				<td><label>
					<input type="text" name="nameproduct" id="prn" value="<?php echo $Product_Name; ?>">
				</label></td>
			</tr>

			<tr>
				<th colspan="" rowspan="" headers="" scope="row" class="center">Quantity</th>
				<td><label>
					<input type="number" name="quantity" id="ql" value="<?php echo $Quantity; ?>">
				</label></td>
			</tr>

			<tr>
				<th colspan="" rowspan="" headers="" scope="row" class="center">Price</th>
				<td><label>
					<input type="number" name="price" id="pri" value="<?php echo $Price; ?>">
				</label></td>
			</tr>

			<tr>
				<th colspan="" rowspan="" headers="" scope="row" class="center">Amount</th>
				<td><label>
					<input type="number" name="amount" id="am" value="<?php echo $Amount;?>">
				</label></td>
			</tr>


			<th colspan="2" rowspan="" headers="" scope="row"><label>
				<input class="btok" type="submit" name="supmit" value="Enter">
				<input type="submit" name="supmit" value="CANCLE">
			</label></th>


		</table>
	</form>

	<table class="type  aia"  bgcolor="#ffccff" border="2" bordercolor="#003333" width="1200px" height="400px">
		<tr>
			<td class="center" colspan="9" rowspan="" headers=""><label><b>Purchase Invoice</b></label></td>
		</tr>

		<tr class="center">
			<td ><label>STT</label></td>
			<td><label>ID_Product</label></td>
			<td><label>Product_Name</label></td>
			<td><label>Quantity</label></td>
			<td><label>Price</label></td>
			<td><label>Disscount</label></td>
			<td><label>Amount</label></td>
			<td><label>Total amount</label></td>

			<tr >
				<td class="center"><label><?php echo $information_shopping["STT"]; ?></label></td> 
				<td class="center"><label><?php echo $information_shopping["product_id"]; ?></label></td>
				<td class="center"><label><?php echo $information_shopping["nameproduct"]; ?></label></td>
				<td class="center"><label><?php echo $information_shopping["quantity"]; ?></label></td>
				<td class="center"><label><?php echo $information_shopping["price"]; ?></label></td>
				<td class="center"><label><?php echo $information_shopping["disscount"]; ?></label></td>
				<td class="center"><label><?php echo $information_shopping["amount"]; ?></label></td>
				<td class="center"><label><?php echo $information_shopping["total"]; ?></label></td>

			</tr>
		</tr>
	</table>
</body>
</html>