<?php
       function caculate1($Quantity, $Price){
			$amout = $Quantity * $Price;

			return $amout;
}


?>


<?php
function caculate2($Quantity, $Price){

	if ($Quantity >= 10 && $Quantity <= 20) {
		$disscount = ($Quantity * $Price)*0.05;
	}

	else {
		$disscount = 0;
	}

	return $disscount;
} 

?>

<?php 
	function calculate3($Quantity, $Price) {
		$disscount=0;
		$amout = $Quantity * $Price;
		if ($Quantity >= 10 && $Quantity <= 20) {
			$disscount = ($Quantity * $Price)*0.05;
		}

		else {
			$disscount = 0;
		}
		$total = $amout - $disscount;
		return $total;
	
}
	?>